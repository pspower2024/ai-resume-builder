import Anthropic from "@anthropic-ai/sdk";
import { NextRequest, NextResponse } from "next/server";

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { type, payload } = body;

    let prompt = "";

    switch (type) {
      case "summary": {
        const { name, title, experience } = payload;
        prompt = `Write a compelling professional summary for a resume. 
Name: ${name}
Title: ${title}
Experience context: ${experience}

Write 2-3 sentences that are punchy, achievement-focused, and quantified where possible. 
Use first-person implied (no "I"). Be specific, not generic. Return only the summary text.`;
        break;
      }

      case "improve": {
        const { text, context } = payload;
        prompt = `Improve this resume text to be more impactful and professional:

Context: ${context}
Original text: ${text}

Make it:
- Start with strong action verbs
- Include specific metrics/numbers where implied
- Be concise and punchy
- Remove weak language ("responsible for", "helped with", "worked on")

Return only the improved text, nothing else.`;
        break;
      }

      case "bullets": {
        const { company, role, description } = payload;
        prompt = `Transform this job description into powerful resume bullet points:

Company: ${company}
Role: ${role}
Description: ${description}

Write 3-4 bullet points that:
- Start with strong action verbs (Led, Built, Increased, Reduced, Shipped, etc.)
- Include specific metrics where possible
- Highlight impact and scope
- Follow CAR format (Context, Action, Result)

Return only the bullet points, each on a new line starting with "•". No other text.`;
        break;
      }

      case "cover": {
        const { resume, jobDescription, companyName } = payload;
        const { personal, experience, skills } = resume;
        prompt = `Write a compelling cover letter for this job application.

APPLICANT:
Name: ${personal.name}
Title: ${personal.title}
Summary: ${personal.summary}
Key Skills: ${skills.slice(0, 6).join(", ")}
Most Recent Role: ${experience[0]?.role} at ${experience[0]?.company}

TARGET COMPANY: ${companyName}
JOB DESCRIPTION:
${jobDescription}

Write a 3-paragraph cover letter that:
1. Opens with a hook, not "I am applying for..."
2. Connects the applicant's specific experience to the role requirements
3. Shows genuine interest in the company
4. Ends with a confident call to action

Tone: Professional but personable. Confident, not arrogant.
Return only the cover letter body (no "Dear..." or signature).`;
        break;
      }

      default:
        return NextResponse.json({ error: "Invalid type" }, { status: 400 });
    }

    const message = await client.messages.create({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1024,
      messages: [{ role: "user", content: prompt }],
    });

    const result =
      message.content[0].type === "text" ? message.content[0].text : "";

    return NextResponse.json({ result });
  } catch (error) {
    console.error("AI generation error:", error);
    return NextResponse.json(
      { error: "Generation failed. Check your API key." },
      { status: 500 }
    );
  }
}
