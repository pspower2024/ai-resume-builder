import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ResuméAI — Craft Your Story",
  description:
    "AI-powered resume builder that helps you craft compelling, job-winning resumes in minutes.",
  keywords: ["resume builder", "AI resume", "CV maker", "job application"],
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="anonymous"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
