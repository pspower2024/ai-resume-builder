import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        display: ["var(--font-display)"],
        body: ["var(--font-body)"],
        mono: ["var(--font-mono)"],
      },
      colors: {
        ink: {
          DEFAULT: "#0D0D0D",
          50: "#F5F5F0",
          100: "#E8E8E0",
          200: "#C8C8B8",
          300: "#A0A090",
          400: "#707060",
          500: "#4A4A3A",
          600: "#2D2D20",
          700: "#1A1A10",
          800: "#111108",
          900: "#0D0D04",
        },
        gold: {
          DEFAULT: "#C9A84C",
          light: "#E8C96A",
          dark: "#9A7A2A",
        },
        cream: {
          DEFAULT: "#F7F4EE",
          dark: "#EDE8DC",
        },
        accent: "#2A5FD4",
      },
      animation: {
        "fade-up": "fadeUp 0.6s ease forwards",
        "fade-in": "fadeIn 0.4s ease forwards",
        shimmer: "shimmer 2s linear infinite",
        "pulse-slow": "pulse 3s ease-in-out infinite",
      },
      keyframes: {
        fadeUp: {
          "0%": { opacity: "0", transform: "translateY(20px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        fadeIn: {
          "0%": { opacity: "0" },
          "100%": { opacity: "1" },
        },
        shimmer: {
          "0%": { backgroundPosition: "-200% 0" },
          "100%": { backgroundPosition: "200% 0" },
        },
      },
    },
  },
  plugins: [],
};
export default config;
