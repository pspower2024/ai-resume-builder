export interface PersonalInfo {
  name: string;
  title: string;
  email: string;
  phone: string;
  location: string;
  linkedin: string;
  website: string;
  summary: string;
}

export interface Experience {
  id: string;
  company: string;
  role: string;
  startDate: string;
  endDate: string;
  current: boolean;
  description: string;
}

export interface Education {
  id: string;
  institution: string;
  degree: string;
  field: string;
  startDate: string;
  endDate: string;
  gpa?: string;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  tech: string;
  url?: string;
}

export interface ResumeData {
  personal: PersonalInfo;
  experience: Experience[];
  education: Education[];
  skills: string[];
  projects: Project[];
}

export type Template = "executive" | "minimal" | "technical";

export const EMPTY_RESUME: ResumeData = {
  personal: {
    name: "",
    title: "",
    email: "",
    phone: "",
    location: "",
    linkedin: "",
    website: "",
    summary: "",
  },
  experience: [],
  education: [],
  skills: [],
  projects: [],
};

export const DEMO_RESUME: ResumeData = {
  personal: {
    name: "Alexandra Chen",
    title: "Senior Product Manager",
    email: "alex.chen@email.com",
    phone: "+1 (415) 555-0182",
    location: "San Francisco, CA",
    linkedin: "linkedin.com/in/alexchen",
    website: "alexchen.io",
    summary:
      "Strategic product leader with 8+ years driving 0→1 products at hypergrowth startups. Led teams of 15+ engineers to ship platforms used by 10M+ users. Deep expertise in B2B SaaS, developer tools, and data infrastructure.",
  },
  experience: [
    {
      id: "e1",
      company: "Vercel",
      role: "Senior Product Manager, Platform",
      startDate: "2021-03",
      endDate: "",
      current: true,
      description:
        "Leading product strategy for Vercel's edge network serving 500M+ requests/day. Grew platform revenue 3× YoY by launching Edge Functions and Analytics. Managed cross-functional team of 18 engineers, 3 designers, and 2 data scientists.",
    },
    {
      id: "e2",
      company: "Stripe",
      role: "Product Manager, Developer Experience",
      startDate: "2018-06",
      endDate: "2021-02",
      current: false,
      description:
        "Owned the developer onboarding funnel, reducing time-to-first-payment from 4 hours to 22 minutes. Launched Stripe CLI with 200K+ weekly active developers. Collaborated with 12-person eng team to ship 40+ API improvements.",
    },
    {
      id: "e3",
      company: "Airbnb",
      role: "Associate Product Manager",
      startDate: "2016-07",
      endDate: "2018-05",
      current: false,
      description:
        "Built pricing intelligence features that increased host revenue by 18% on average. Ran 60+ A/B experiments per quarter. Partnered with data science team to build dynamic pricing models.",
    },
  ],
  education: [
    {
      id: "ed1",
      institution: "Stanford University",
      degree: "B.S.",
      field: "Computer Science",
      startDate: "2012-09",
      endDate: "2016-06",
      gpa: "3.8",
    },
  ],
  skills: [
    "Product Strategy",
    "Roadmapping",
    "SQL",
    "Python",
    "Figma",
    "A/B Testing",
    "OKRs",
    "Agile / Scrum",
    "Data Analysis",
    "Go-to-Market",
  ],
  projects: [
    {
      id: "p1",
      name: "OpenMetrics",
      description:
        "Open-source observability framework with 2.4K GitHub stars. Built real-time dashboards and alerting for distributed systems.",
      tech: "TypeScript, React, ClickHouse",
      url: "github.com/alexchen/openmetrics",
    },
  ],
};

export function generateId(): string {
  return Math.random().toString(36).slice(2, 9);
}
