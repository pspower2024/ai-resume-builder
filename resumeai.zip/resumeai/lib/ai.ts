import { ResumeData } from "./types";

export async function generateSummary(
  name: string,
  title: string,
  experience: string
): Promise<string> {
  const res = await fetch("/api/generate", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      type: "summary",
      payload: { name, title, experience },
    }),
  });
  if (!res.ok) throw new Error("Generation failed");
  const data = await res.json();
  return data.result;
}

export async function improveText(
  text: string,
  context: string
): Promise<string> {
  const res = await fetch("/api/generate", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ type: "improve", payload: { text, context } }),
  });
  if (!res.ok) throw new Error("Generation failed");
  const data = await res.json();
  return data.result;
}

export async function generateBullets(
  company: string,
  role: string,
  description: string
): Promise<string> {
  const res = await fetch("/api/generate", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      type: "bullets",
      payload: { company, role, description },
    }),
  });
  if (!res.ok) throw new Error("Generation failed");
  const data = await res.json();
  return data.result;
}

export async function generateCoverLetter(
  resume: ResumeData,
  jobDescription: string,
  companyName: string
): Promise<string> {
  const res = await fetch("/api/generate", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      type: "cover",
      payload: { resume, jobDescription, companyName },
    }),
  });
  if (!res.ok) throw new Error("Generation failed");
  const data = await res.json();
  return data.result;
}
