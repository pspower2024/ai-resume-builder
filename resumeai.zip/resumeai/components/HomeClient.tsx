"use client";

import Link from "next/link";

const features = [
  {
    icon: "✦",
    title: "AI Content Generation",
    desc: "One click transforms your rough notes into polished, quantified bullet points hiring managers love.",
  },
  {
    icon: "◈",
    title: "Live Preview",
    desc: "See your resume update in real time across three carefully designed templates.",
  },
  {
    icon: "◎",
    title: "Cover Letter Writer",
    desc: "Paste a job description and get a tailored cover letter in seconds.",
  },
  {
    icon: "⟁",
    title: "PDF Export",
    desc: "Download print-perfect PDFs via your browser's native print dialog.",
  },
];

const steps = [
  { num: "01", label: "Fill in your details" },
  { num: "02", label: "Let AI enhance your content" },
  { num: "03", label: "Pick a template" },
  { num: "04", label: "Export as PDF" },
];

export default function HomeClient() {
  return (
    <div className="min-h-screen bg-[#0D0D0D] text-[#F7F4EE] overflow-hidden">
      {/* Noise texture overlay */}
      <div
        className="fixed inset-0 pointer-events-none opacity-[0.03] z-10"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='1'/%3E%3C/svg%3E")`,
        }}
      />

      {/* Nav */}
      <nav className="relative z-20 flex items-center justify-between px-8 py-6 border-b border-white/5">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded bg-[#C9A84C] flex items-center justify-center">
            <span className="text-[#0D0D0D] text-xs font-bold" style={{ fontFamily: "DM Serif Display, serif" }}>R</span>
          </div>
          <span className="font-semibold tracking-tight" style={{ fontFamily: "DM Serif Display, serif" }}>
            Resumé<span className="text-[#C9A84C]">AI</span>
          </span>
        </div>
        <div className="flex items-center gap-6">
          <a href="#features" className="text-sm text-white/50 hover:text-white/90 transition-colors">Features</a>
          <a href="#how" className="text-sm text-white/50 hover:text-white/90 transition-colors">How it works</a>
          <Link
            href="/builder"
            className="text-sm bg-[#C9A84C] text-[#0D0D0D] px-4 py-2 rounded font-medium hover:bg-[#E8C96A] transition-colors"
          >
            Start free →
          </Link>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative z-20 px-8 pt-28 pb-24 max-w-5xl mx-auto">
        {/* Decorative lines */}
        <div className="absolute top-20 right-0 w-px h-64 bg-gradient-to-b from-transparent via-[#C9A84C]/30 to-transparent" />
        <div className="absolute top-32 left-0 w-px h-48 bg-gradient-to-b from-transparent via-white/10 to-transparent" />

        <div className="animate-fade-up">
          <div className="inline-flex items-center gap-2 border border-[#C9A84C]/30 rounded-full px-4 py-1.5 mb-8 bg-[#C9A84C]/5">
            <div className="w-1.5 h-1.5 rounded-full bg-[#C9A84C] animate-pulse" />
            <span className="text-xs text-[#C9A84C] tracking-widest uppercase font-medium">AI-Powered Resume Builder</span>
          </div>

          <h1
            className="text-6xl md:text-7xl leading-[1.05] mb-6 tracking-tight"
            style={{ fontFamily: "DM Serif Display, serif" }}
          >
            Your career story,
            <br />
            <span className="italic text-[#C9A84C]">perfectly told.</span>
          </h1>

          <p className="text-lg text-white/50 max-w-xl mb-10 leading-relaxed">
            Stop staring at a blank page. ResuméAI crafts compelling, ATS-optimized resumes 
            with the precision of a seasoned career coach — in minutes, not hours.
          </p>

          <div className="flex items-center gap-4">
            <Link
              href="/builder"
              className="group inline-flex items-center gap-2 bg-[#C9A84C] text-[#0D0D0D] px-6 py-3 rounded font-semibold hover:bg-[#E8C96A] transition-all duration-200 hover:gap-3"
            >
              Build my resume
              <span className="group-hover:translate-x-1 transition-transform">→</span>
            </Link>
            <Link
              href="/builder"
              className="inline-flex items-center gap-2 text-sm text-white/40 hover:text-white/70 transition-colors"
            >
              View demo →
            </Link>
          </div>
        </div>

        {/* Hero visual */}
        <div className="mt-20 animate-fade-up delay-300 relative">
          <div className="absolute -inset-4 bg-gradient-to-b from-[#C9A84C]/5 to-transparent rounded-2xl" />
          <div className="relative border border-white/10 rounded-xl overflow-hidden bg-[#111108]">
            <div className="flex items-center gap-2 px-4 py-3 border-b border-white/5 bg-[#0D0D0D]/50">
              <div className="flex gap-1.5">
                <div className="w-3 h-3 rounded-full bg-white/10" />
                <div className="w-3 h-3 rounded-full bg-white/10" />
                <div className="w-3 h-3 rounded-full bg-white/10" />
              </div>
              <div className="flex-1 mx-4 h-5 bg-white/5 rounded-full text-white/20 text-xs flex items-center justify-center">
                resumeai.app/builder
              </div>
            </div>
            <div className="grid grid-cols-2 gap-0">
              {/* Form side preview */}
              <div className="p-6 border-r border-white/5">
                <div className="space-y-3">
                  <div className="h-3 bg-white/10 rounded-full w-24" />
                  <div className="h-8 bg-white/5 rounded border border-white/10 flex items-center px-3">
                    <span className="text-white/30 text-xs">Alexandra Chen</span>
                  </div>
                  <div className="h-8 bg-white/5 rounded border border-white/10 flex items-center px-3">
                    <span className="text-white/30 text-xs">Senior Product Manager</span>
                  </div>
                  <div className="mt-4 h-3 bg-white/10 rounded-full w-20" />
                  <div className="h-16 bg-white/5 rounded border border-white/10 flex items-start p-3">
                    <span className="text-white/20 text-xs leading-relaxed">Strategic product leader with 8+ years driving 0→1 products...</span>
                  </div>
                  <button className="w-full h-8 bg-[#C9A84C]/20 border border-[#C9A84C]/40 rounded text-[#C9A84C] text-xs flex items-center justify-center gap-1.5">
                    <span>✦</span> Generate with AI
                  </button>
                </div>
              </div>
              {/* Preview side */}
              <div className="p-6 bg-white/[0.02]">
                <div className="bg-white rounded p-4 shadow-xl scale-[0.85] origin-top">
                  <div className="border-b-2 border-[#0D0D0D] pb-3 mb-3">
                    <div className="text-[#0D0D0D] font-bold text-sm" style={{ fontFamily: "DM Serif Display, serif" }}>Alexandra Chen</div>
                    <div className="text-[#4A4A3A] text-xs">Senior Product Manager · San Francisco, CA</div>
                  </div>
                  <div className="space-y-1.5">
                    <div className="h-1.5 bg-gray-200 rounded-full w-full" />
                    <div className="h-1.5 bg-gray-200 rounded-full w-5/6" />
                    <div className="h-1.5 bg-gray-100 rounded-full w-4/6" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="relative z-20 px-8 py-24 border-t border-white/5">
        <div className="max-w-5xl mx-auto">
          <div className="mb-16">
            <p className="text-[#C9A84C] text-xs tracking-widest uppercase mb-3">What you get</p>
            <h2 className="text-4xl" style={{ fontFamily: "DM Serif Display, serif" }}>
              Everything you need to land the interview
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-white/5">
            {features.map((f, i) => (
              <div key={i} className="bg-[#0D0D0D] p-8 hover:bg-[#111108] transition-colors group">
                <div className="text-2xl text-[#C9A84C] mb-4 group-hover:scale-110 transition-transform inline-block">
                  {f.icon}
                </div>
                <h3 className="text-lg font-medium mb-2" style={{ fontFamily: "DM Serif Display, serif" }}>{f.title}</h3>
                <p className="text-sm text-white/40 leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section id="how" className="relative z-20 px-8 py-24 border-t border-white/5">
        <div className="max-w-5xl mx-auto">
          <div className="mb-16">
            <p className="text-[#C9A84C] text-xs tracking-widest uppercase mb-3">Process</p>
            <h2 className="text-4xl" style={{ fontFamily: "DM Serif Display, serif" }}>
              Four steps to your dream resume
            </h2>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {steps.map((s, i) => (
              <div key={i} className="relative">
                {i < steps.length - 1 && (
                  <div className="hidden md:block absolute top-6 left-full w-full h-px bg-gradient-to-r from-[#C9A84C]/30 to-transparent z-10" />
                )}
                <div className="text-4xl font-bold text-white/5 mb-3" style={{ fontFamily: "DM Serif Display, serif" }}>
                  {s.num}
                </div>
                <div className="text-sm text-white/70 leading-snug">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="relative z-20 px-8 py-24 border-t border-white/5">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-5xl mb-6" style={{ fontFamily: "DM Serif Display, serif" }}>
            Ready to craft your story?
          </h2>
          <p className="text-white/40 mb-10">
            Join thousands of professionals who landed their next role with ResuméAI.
          </p>
          <Link
            href="/builder"
            className="inline-flex items-center gap-2 bg-[#C9A84C] text-[#0D0D0D] px-8 py-4 rounded font-semibold text-lg hover:bg-[#E8C96A] transition-all duration-200"
          >
            Start building — it&apos;s free
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative z-20 px-8 py-8 border-t border-white/5 flex items-center justify-between">
        <span className="text-white/20 text-sm" style={{ fontFamily: "DM Serif Display, serif" }}>
          Resumé<span className="text-[#C9A84C]/50">AI</span>
        </span>
        <span className="text-white/20 text-xs">Powered by Claude</span>
      </footer>
    </div>
  );
}
