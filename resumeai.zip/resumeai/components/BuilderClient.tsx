"use client";

import { useState } from "react";
import { ResumeData, Template, DEMO_RESUME, EMPTY_RESUME } from "@/lib/types";
import BuilderForm from "./BuilderForm";
import ResumePreview from "./ResumePreview";
import Navbar from "./ui/Navbar";
import Toast from "./ui/Toast";
import CoverLetterModal from "./ui/CoverLetterModal";

export default function BuilderClient() {
  const [resume, setResume] = useState<ResumeData>(DEMO_RESUME);
  const [template, setTemplate] = useState<Template>("executive");
  const [toast, setToast] = useState<{ msg: string; type?: "success" | "error" } | null>(null);
  const [showCover, setShowCover] = useState(false);
  const [activeTab, setActiveTab] = useState<"form" | "preview">("form");

  function showToast(msg: string, type: "success" | "error" = "success") {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3500);
  }

  function handlePrint() {
    window.print();
  }

  function handleReset() {
    if (confirm("Reset to blank resume?")) {
      setResume(EMPTY_RESUME);
      showToast("Cleared — start fresh!");
    }
  }

  function handleLoadDemo() {
    setResume(DEMO_RESUME);
    showToast("Demo resume loaded");
  }

  return (
    <div className="min-h-screen bg-[#F7F4EE] flex flex-col">
      <Navbar
        template={template}
        onTemplateChange={setTemplate}
        onPrint={handlePrint}
        onCoverLetter={() => setShowCover(true)}
        onReset={handleReset}
        onLoadDemo={handleLoadDemo}
      />

      {/* Mobile tab bar */}
      <div className="md:hidden flex border-b border-[#0D0D0D]/10 bg-white no-print">
        {(["form", "preview"] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`flex-1 py-3 text-sm font-medium capitalize transition-colors ${
              activeTab === tab
                ? "text-[#0D0D0D] border-b-2 border-[#C9A84C]"
                : "text-[#0D0D0D]/40"
            }`}
          >
            {tab === "form" ? "Edit" : "Preview"}
          </button>
        ))}
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Form panel */}
        <div
          className={`
            w-full md:w-[420px] lg:w-[460px] flex-shrink-0 
            overflow-y-auto bg-white border-r border-[#0D0D0D]/10
            no-print
            ${activeTab === "form" ? "block" : "hidden md:block"}
          `}
        >
          <BuilderForm
            resume={resume}
            onChange={setResume}
            onToast={showToast}
          />
        </div>

        {/* Preview panel */}
        <div
          className={`
            flex-1 overflow-y-auto bg-[#EDE8DC]
            ${activeTab === "preview" ? "block" : "hidden md:block"}
          `}
        >
          <ResumePreview resume={resume} template={template} />
        </div>
      </div>

      {toast && (
        <Toast message={toast.msg} type={toast.type} onClose={() => setToast(null)} />
      )}

      {showCover && (
        <CoverLetterModal
          resume={resume}
          onClose={() => setShowCover(false)}
          onToast={showToast}
        />
      )}
    </div>
  );
}
