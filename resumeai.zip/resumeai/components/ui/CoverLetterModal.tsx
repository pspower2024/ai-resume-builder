"use client";

import { useState } from "react";
import { ResumeData } from "@/lib/types";
import { generateCoverLetter } from "@/lib/ai";
import Spinner from "./Spinner";

interface Props {
  resume: ResumeData;
  onClose: () => void;
  onToast: (msg: string, type?: "success" | "error") => void;
}

export default function CoverLetterModal({ resume, onClose, onToast }: Props) {
  const [company, setCompany] = useState("");
  const [jd, setJd] = useState("");
  const [result, setResult] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleGenerate() {
    if (!company.trim() || !jd.trim()) {
      onToast("Add company name and job description", "error");
      return;
    }
    setLoading(true);
    try {
      const letter = await generateCoverLetter(resume, jd, company);
      setResult(letter);
    } catch {
      onToast("Cover letter generation failed", "error");
    } finally {
      setLoading(false);
    }
  }

  function handleCopy() {
    navigator.clipboard.writeText(result);
    onToast("Copied to clipboard ✦");
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 no-print">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-[#0D0D0D]/70 backdrop-blur-sm animate-fade-in"
        onClick={onClose}
      />

      {/* Modal */}
      <div className="relative bg-white rounded-xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col animate-fade-up">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#0D0D0D]/10">
          <div>
            <h2 className="font-semibold text-[#0D0D0D]" style={{ fontFamily: "DM Serif Display, serif" }}>
              Cover Letter Generator
            </h2>
            <p className="text-xs text-[#0D0D0D]/40 mt-0.5">
              Paste a job description for a tailored cover letter
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-[#0D0D0D]/30 hover:text-[#0D0D0D] transition-colors text-lg"
          >
            ✕
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {!result ? (
            <>
              <div>
                <label className="text-xs font-medium text-[#0D0D0D]/50 uppercase tracking-wider block mb-1.5">
                  Company Name
                </label>
                <input
                  value={company}
                  onChange={(e) => setCompany(e.target.value)}
                  placeholder="Stripe"
                  className="w-full px-3 py-2.5 text-sm border border-[#0D0D0D]/12 rounded bg-white focus:outline-none focus:border-[#C9A84C] transition-colors text-[#0D0D0D] placeholder-[#0D0D0D]/25"
                />
              </div>
              <div>
                <label className="text-xs font-medium text-[#0D0D0D]/50 uppercase tracking-wider block mb-1.5">
                  Job Description
                </label>
                <textarea
                  value={jd}
                  onChange={(e) => setJd(e.target.value)}
                  rows={10}
                  placeholder="Paste the full job description here..."
                  className="w-full px-3 py-2.5 text-sm border border-[#0D0D0D]/12 rounded bg-white focus:outline-none focus:border-[#C9A84C] transition-colors text-[#0D0D0D] placeholder-[#0D0D0D]/25 leading-relaxed"
                />
              </div>
            </>
          ) : (
            <div>
              <div className="flex items-center justify-between mb-3">
                <p className="text-xs font-medium text-[#0D0D0D]/50 uppercase tracking-wider">
                  Generated Cover Letter
                </p>
                <button
                  onClick={() => setResult("")}
                  className="text-xs text-[#0D0D0D]/40 hover:text-[#0D0D0D]/70 transition-colors"
                >
                  ← Regenerate
                </button>
              </div>
              <div className="bg-[#F7F4EE] rounded-lg p-5 text-sm text-[#0D0D0D]/75 leading-relaxed whitespace-pre-wrap border border-[#0D0D0D]/8">
                {result}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-[#0D0D0D]/10">
          <button
            onClick={onClose}
            className="text-sm text-[#0D0D0D]/40 hover:text-[#0D0D0D]/70 transition-colors"
          >
            Close
          </button>
          <div className="flex gap-3">
            {result && (
              <button
                onClick={handleCopy}
                className="text-sm border border-[#0D0D0D]/15 text-[#0D0D0D]/60 hover:text-[#0D0D0D] hover:border-[#0D0D0D]/30 px-4 py-2 rounded transition-all"
              >
                Copy text
              </button>
            )}
            {!result && (
              <button
                onClick={handleGenerate}
                disabled={loading}
                className="text-sm bg-[#C9A84C] text-[#0D0D0D] px-5 py-2 rounded font-semibold hover:bg-[#E8C96A] transition-colors disabled:opacity-60 flex items-center gap-2"
              >
                {loading ? (
                  <>
                    <Spinner size="sm" />
                    Generating...
                  </>
                ) : (
                  <>✦ Generate</>
                )}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
