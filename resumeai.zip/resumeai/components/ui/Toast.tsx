"use client";

interface Props {
  message: string;
  type?: "success" | "error";
  onClose: () => void;
}

export default function Toast({ message, type = "success", onClose }: Props) {
  return (
    <div className="fixed bottom-6 right-6 z-50 animate-slide-in no-print">
      <div
        className={`flex items-center gap-3 px-4 py-3 rounded-lg shadow-xl text-sm font-medium ${
          type === "success"
            ? "bg-[#0D0D0D] text-[#F7F4EE] border border-[#C9A84C]/20"
            : "bg-red-950 text-red-200 border border-red-800"
        }`}
      >
        <span className={type === "success" ? "text-[#C9A84C]" : "text-red-400"}>
          {type === "success" ? "✦" : "✕"}
        </span>
        {message}
        <button
          onClick={onClose}
          className="ml-2 opacity-40 hover:opacity-70 transition-opacity"
        >
          ✕
        </button>
      </div>
    </div>
  );
}
