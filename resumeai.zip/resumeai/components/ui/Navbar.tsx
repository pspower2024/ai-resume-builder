"use client";

import Link from "next/link";
import { Template } from "@/lib/types";

interface Props {
  template: Template;
  onTemplateChange: (t: Template) => void;
  onPrint: () => void;
  onCoverLetter: () => void;
  onReset: () => void;
  onLoadDemo: () => void;
}

const templates: { id: Template; label: string }[] = [
  { id: "executive", label: "Executive" },
  { id: "minimal", label: "Minimal" },
  { id: "technical", label: "Technical" },
];

export default function Navbar({
  template,
  onTemplateChange,
  onPrint,
  onCoverLetter,
  onReset,
  onLoadDemo,
}: Props) {
  return (
    <nav className="h-14 bg-[#0D0D0D] flex items-center justify-between px-4 md:px-6 flex-shrink-0 no-print z-30">
      {/* Logo */}
      <Link href="/" className="flex items-center gap-2">
        <div className="w-6 h-6 rounded bg-[#C9A84C] flex items-center justify-center">
          <span className="text-[#0D0D0D] text-[10px] font-bold" style={{ fontFamily: "DM Serif Display, serif" }}>R</span>
        </div>
        <span className="text-[#F7F4EE] text-sm font-medium hidden sm:block" style={{ fontFamily: "DM Serif Display, serif" }}>
          Resumé<span className="text-[#C9A84C]">AI</span>
        </span>
      </Link>

      {/* Template switcher */}
      <div className="flex items-center gap-1 bg-white/5 rounded p-1">
        {templates.map((t) => (
          <button
            key={t.id}
            onClick={() => onTemplateChange(t.id)}
            className={`text-xs px-3 py-1.5 rounded transition-all font-medium ${
              template === t.id
                ? "bg-[#C9A84C] text-[#0D0D0D]"
                : "text-[#F7F4EE]/40 hover:text-[#F7F4EE]/80"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Actions */}
      <div className="flex items-center gap-2">
        <button
          onClick={onLoadDemo}
          className="text-xs text-[#F7F4EE]/30 hover:text-[#F7F4EE]/70 transition-colors hidden md:block"
        >
          Demo
        </button>
        <button
          onClick={onReset}
          className="text-xs text-[#F7F4EE]/30 hover:text-[#F7F4EE]/70 transition-colors hidden md:block"
        >
          Clear
        </button>
        <button
          onClick={onCoverLetter}
          className="text-xs border border-white/15 text-[#F7F4EE]/60 hover:text-[#F7F4EE] hover:border-white/30 px-3 py-1.5 rounded transition-all hidden sm:block"
        >
          Cover Letter
        </button>
        <button
          onClick={onPrint}
          className="text-xs bg-[#C9A84C] text-[#0D0D0D] px-4 py-1.5 rounded font-semibold hover:bg-[#E8C96A] transition-colors flex items-center gap-1.5"
        >
          <svg width="12" height="12" viewBox="0 0 16 16" fill="none">
            <path d="M4 1h8v4H4V1zM1 6h14v7H1V6zM4 10h8M4 13h5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
          </svg>
          Export PDF
        </button>
      </div>
    </nav>
  );
}
