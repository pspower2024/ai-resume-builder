"use client";

import { ResumeData, Template } from "@/lib/types";
import ExecutiveResume from "./resume-templates/ExecutiveResume";
import MinimalResume from "./resume-templates/MinimalResume";
import TechnicalResume from "./resume-templates/TechnicalResume";

interface Props {
  resume: ResumeData;
  template: Template;
}

export default function ResumePreview({ resume, template }: Props) {
  return (
    <div className="p-6 md:p-10 flex flex-col items-center min-h-full">
      <div
        id="resume-print"
        className="w-full max-w-[794px] shadow-2xl shadow-[#0D0D0D]/20"
        style={{ aspectRatio: "auto" }}
      >
        {template === "executive" && <ExecutiveResume resume={resume} />}
        {template === "minimal" && <MinimalResume resume={resume} />}
        {template === "technical" && <TechnicalResume resume={resume} />}
      </div>
    </div>
  );
}
