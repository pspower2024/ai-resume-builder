"use client";

import { useState } from "react";
import { ResumeData, Experience, Education, Project, generateId } from "@/lib/types";
import { generateSummary, improveText, generateBullets } from "@/lib/ai";
import Spinner from "./ui/Spinner";

interface Props {
  resume: ResumeData;
  onChange: (r: ResumeData) => void;
  onToast: (msg: string, type?: "success" | "error") => void;
}

type Section = "personal" | "experience" | "education" | "skills" | "projects";

export default function BuilderForm({ resume, onChange, onToast }: Props) {
  const [active, setActive] = useState<Section>("personal");
  const [loading, setLoading] = useState<string | null>(null);
  const [skillInput, setSkillInput] = useState("");

  function up(path: string[], value: unknown) {
    const next = JSON.parse(JSON.stringify(resume)) as ResumeData;
    let obj: Record<string, unknown> = next as unknown as Record<string, unknown>;
    for (let i = 0; i < path.length - 1; i++) {
      obj = obj[path[i]] as Record<string, unknown>;
    }
    obj[path[path.length - 1]] = value;
    onChange(next);
  }

  // Personal
  function updatePersonal(field: string, val: string) {
    onChange({ ...resume, personal: { ...resume.personal, [field]: val } });
  }

  // Experience
  function addExp() {
    const e: Experience = {
      id: generateId(),
      company: "",
      role: "",
      startDate: "",
      endDate: "",
      current: false,
      description: "",
    };
    onChange({ ...resume, experience: [e, ...resume.experience] });
  }

  function updateExp(id: string, field: string, val: unknown) {
    onChange({
      ...resume,
      experience: resume.experience.map((e) =>
        e.id === id ? { ...e, [field]: val } : e
      ),
    });
  }

  function removeExp(id: string) {
    onChange({ ...resume, experience: resume.experience.filter((e) => e.id !== id) });
  }

  // Education
  function addEdu() {
    const e: Education = {
      id: generateId(),
      institution: "",
      degree: "",
      field: "",
      startDate: "",
      endDate: "",
      gpa: "",
    };
    onChange({ ...resume, education: [e, ...resume.education] });
  }

  function updateEdu(id: string, field: string, val: string) {
    onChange({
      ...resume,
      education: resume.education.map((e) =>
        e.id === id ? { ...e, [field]: val } : e
      ),
    });
  }

  function removeEdu(id: string) {
    onChange({ ...resume, education: resume.education.filter((e) => e.id !== id) });
  }

  // Skills
  function addSkill() {
    const s = skillInput.trim();
    if (!s || resume.skills.includes(s)) return;
    onChange({ ...resume, skills: [...resume.skills, s] });
    setSkillInput("");
  }

  function removeSkill(s: string) {
    onChange({ ...resume, skills: resume.skills.filter((x) => x !== s) });
  }

  // Projects
  function addProject() {
    const p: Project = {
      id: generateId(),
      name: "",
      description: "",
      tech: "",
      url: "",
    };
    onChange({ ...resume, projects: [p, ...resume.projects] });
  }

  function updateProject(id: string, field: string, val: string) {
    onChange({
      ...resume,
      projects: resume.projects.map((p) =>
        p.id === id ? { ...p, [field]: val } : p
      ),
    });
  }

  function removeProject(id: string) {
    onChange({ ...resume, projects: resume.projects.filter((p) => p.id !== id) });
  }

  // AI actions
  async function handleGenSummary() {
    const { name, title } = resume.personal;
    if (!name && !title) {
      onToast("Add your name and title first", "error");
      return;
    }
    const expStr = resume.experience
      .slice(0, 2)
      .map((e) => `${e.role} at ${e.company}`)
      .join(", ");
    setLoading("summary");
    try {
      const result = await generateSummary(name, title, expStr);
      updatePersonal("summary", result);
      onToast("Summary generated ✦");
    } catch {
      onToast("AI generation failed — check API key", "error");
    } finally {
      setLoading(null);
    }
  }

  async function handleImproveSummary() {
    if (!resume.personal.summary) {
      onToast("Write a summary first", "error");
      return;
    }
    setLoading("improve-summary");
    try {
      const result = await improveText(
        resume.personal.summary,
        `Professional summary for ${resume.personal.title}`
      );
      updatePersonal("summary", result);
      onToast("Summary improved ✦");
    } catch {
      onToast("AI generation failed", "error");
    } finally {
      setLoading(null);
    }
  }

  async function handleGenBullets(exp: Experience) {
    if (!exp.role && !exp.company) {
      onToast("Add company and role first", "error");
      return;
    }
    setLoading(`bullets-${exp.id}`);
    try {
      const result = await generateBullets(
        exp.company,
        exp.role,
        exp.description
      );
      updateExp(exp.id, "description", result);
      onToast("Bullets generated ✦");
    } catch {
      onToast("AI generation failed", "error");
    } finally {
      setLoading(null);
    }
  }

  async function handleImproveExp(exp: Experience) {
    if (!exp.description) {
      onToast("Add a description first", "error");
      return;
    }
    setLoading(`improve-${exp.id}`);
    try {
      const result = await improveText(
        exp.description,
        `${exp.role} at ${exp.company}`
      );
      updateExp(exp.id, "description", result);
      onToast("Description improved ✦");
    } catch {
      onToast("AI generation failed", "error");
    } finally {
      setLoading(null);
    }
  }

  const sections: { id: Section; label: string; icon: string }[] = [
    { id: "personal", label: "Personal", icon: "◉" },
    { id: "experience", label: "Experience", icon: "◈" },
    { id: "education", label: "Education", icon: "◎" },
    { id: "skills", label: "Skills", icon: "✦" },
    { id: "projects", label: "Projects", icon: "⟁" },
  ];

  return (
    <div className="flex flex-col h-full">
      {/* Section tabs */}
      <div className="flex border-b border-[#0D0D0D]/8 overflow-x-auto">
        {sections.map((s) => (
          <button
            key={s.id}
            onClick={() => setActive(s.id)}
            className={`flex-1 min-w-fit flex flex-col items-center gap-0.5 py-3 px-4 text-xs transition-all ${
              active === s.id
                ? "text-[#0D0D0D] border-b-2 border-[#C9A84C] bg-[#C9A84C]/5"
                : "text-[#0D0D0D]/40 hover:text-[#0D0D0D]/70"
            }`}
          >
            <span className="text-base">{s.icon}</span>
            <span className="font-medium">{s.label}</span>
          </button>
        ))}
      </div>

      {/* Form content */}
      <div className="flex-1 overflow-y-auto p-6 space-y-5">
        {/* Personal */}
        {active === "personal" && (
          <div className="space-y-4 animate-fade-in">
            <SectionHeader title="Personal Information" />
            <div className="grid grid-cols-2 gap-3">
              <Field label="Full Name" value={resume.personal.name} onChange={(v) => updatePersonal("name", v)} placeholder="Alexandra Chen" />
              <Field label="Job Title" value={resume.personal.title} onChange={(v) => updatePersonal("title", v)} placeholder="Senior PM" />
              <Field label="Email" value={resume.personal.email} onChange={(v) => updatePersonal("email", v)} placeholder="alex@email.com" type="email" />
              <Field label="Phone" value={resume.personal.phone} onChange={(v) => updatePersonal("phone", v)} placeholder="+1 (415) 555-0100" />
              <Field label="Location" value={resume.personal.location} onChange={(v) => updatePersonal("location", v)} placeholder="San Francisco, CA" />
              <Field label="LinkedIn" value={resume.personal.linkedin} onChange={(v) => updatePersonal("linkedin", v)} placeholder="linkedin.com/in/you" />
              <Field label="Website" value={resume.personal.website} onChange={(v) => updatePersonal("website", v)} placeholder="yoursite.com" className="col-span-2" />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-medium text-[#0D0D0D]/60 uppercase tracking-wider">Professional Summary</label>
                <div className="flex gap-1.5">
                  <AIButton
                    label="Generate"
                    onClick={handleGenSummary}
                    loading={loading === "summary"}
                    icon="✦"
                  />
                  <AIButton
                    label="Improve"
                    onClick={handleImproveSummary}
                    loading={loading === "improve-summary"}
                    icon="◈"
                    variant="secondary"
                  />
                </div>
              </div>
              <textarea
                value={resume.personal.summary}
                onChange={(e) => updatePersonal("summary", e.target.value)}
                rows={4}
                placeholder="Strategic product leader with 8+ years..."
                className="w-full px-3 py-2 text-sm border border-[#0D0D0D]/12 rounded bg-white focus:outline-none focus:border-[#C9A84C] transition-colors text-[#0D0D0D] placeholder-[#0D0D0D]/25 leading-relaxed"
              />
            </div>
          </div>
        )}

        {/* Experience */}
        {active === "experience" && (
          <div className="space-y-4 animate-fade-in">
            <div className="flex items-center justify-between">
              <SectionHeader title="Work Experience" />
              <button
                onClick={addExp}
                className="text-xs bg-[#0D0D0D] text-[#F7F4EE] px-3 py-1.5 rounded hover:bg-[#C9A84C] hover:text-[#0D0D0D] transition-colors font-medium"
              >
                + Add
              </button>
            </div>

            {resume.experience.length === 0 && (
              <EmptyState label="No experience added yet" action="+ Add position" onClick={addExp} />
            )}

            {resume.experience.map((exp) => (
              <div key={exp.id} className="border border-[#0D0D0D]/10 rounded-lg p-4 space-y-3 bg-[#F7F4EE]/50">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-[#0D0D0D]/40 uppercase tracking-wider">
                    {exp.role || "New Position"}
                  </span>
                  <button onClick={() => removeExp(exp.id)} className="text-[#0D0D0D]/20 hover:text-red-500 text-sm transition-colors">✕</button>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <Field label="Company" value={exp.company} onChange={(v) => updateExp(exp.id, "company", v)} placeholder="Vercel" />
                  <Field label="Role / Title" value={exp.role} onChange={(v) => updateExp(exp.id, "role", v)} placeholder="Senior PM" />
                  <Field label="Start Date" value={exp.startDate} onChange={(v) => updateExp(exp.id, "startDate", v)} placeholder="2021-03" />
                  <div>
                    <Field label="End Date" value={exp.endDate} onChange={(v) => updateExp(exp.id, "endDate", v)} placeholder="2024-01" disabled={exp.current} />
                    <label className="flex items-center gap-1.5 mt-1.5 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={exp.current}
                        onChange={(e) => updateExp(exp.id, "current", e.target.checked)}
                        className="w-3 h-3 accent-[#C9A84C]"
                      />
                      <span className="text-xs text-[#0D0D0D]/50">Current role</span>
                    </label>
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-medium text-[#0D0D0D]/60 uppercase tracking-wider">Description</label>
                    <div className="flex gap-1.5">
                      <AIButton
                        label="Bullets"
                        onClick={() => handleGenBullets(exp)}
                        loading={loading === `bullets-${exp.id}`}
                        icon="✦"
                      />
                      <AIButton
                        label="Improve"
                        onClick={() => handleImproveExp(exp)}
                        loading={loading === `improve-${exp.id}`}
                        icon="◈"
                        variant="secondary"
                      />
                    </div>
                  </div>
                  <textarea
                    value={exp.description}
                    onChange={(e) => updateExp(exp.id, "description", e.target.value)}
                    rows={4}
                    placeholder="• Led cross-functional team of 12 engineers...&#10;• Increased conversion by 34% through..."
                    className="w-full px-3 py-2 text-sm border border-[#0D0D0D]/12 rounded bg-white focus:outline-none focus:border-[#C9A84C] transition-colors text-[#0D0D0D] placeholder-[#0D0D0D]/25 leading-relaxed"
                  />
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Education */}
        {active === "education" && (
          <div className="space-y-4 animate-fade-in">
            <div className="flex items-center justify-between">
              <SectionHeader title="Education" />
              <button
                onClick={addEdu}
                className="text-xs bg-[#0D0D0D] text-[#F7F4EE] px-3 py-1.5 rounded hover:bg-[#C9A84C] hover:text-[#0D0D0D] transition-colors font-medium"
              >
                + Add
              </button>
            </div>

            {resume.education.length === 0 && (
              <EmptyState label="No education added yet" action="+ Add school" onClick={addEdu} />
            )}

            {resume.education.map((edu) => (
              <div key={edu.id} className="border border-[#0D0D0D]/10 rounded-lg p-4 space-y-3 bg-[#F7F4EE]/50">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-[#0D0D0D]/40 uppercase tracking-wider">
                    {edu.institution || "New School"}
                  </span>
                  <button onClick={() => removeEdu(edu.id)} className="text-[#0D0D0D]/20 hover:text-red-500 text-sm transition-colors">✕</button>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Institution" value={edu.institution} onChange={(v) => updateEdu(edu.id, "institution", v)} placeholder="Stanford University" className="col-span-2" />
                  <Field label="Degree" value={edu.degree} onChange={(v) => updateEdu(edu.id, "degree", v)} placeholder="B.S." />
                  <Field label="Field of Study" value={edu.field} onChange={(v) => updateEdu(edu.id, "field", v)} placeholder="Computer Science" />
                  <Field label="Start Date" value={edu.startDate} onChange={(v) => updateEdu(edu.id, "startDate", v)} placeholder="2012-09" />
                  <Field label="End Date" value={edu.endDate} onChange={(v) => updateEdu(edu.id, "endDate", v)} placeholder="2016-06" />
                  <Field label="GPA (optional)" value={edu.gpa || ""} onChange={(v) => updateEdu(edu.id, "gpa", v)} placeholder="3.8" />
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Skills */}
        {active === "skills" && (
          <div className="space-y-4 animate-fade-in">
            <SectionHeader title="Skills" />
            <div className="flex gap-2">
              <input
                value={skillInput}
                onChange={(e) => setSkillInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && addSkill()}
                placeholder="Type a skill and press Enter..."
                className="flex-1 px-3 py-2 text-sm border border-[#0D0D0D]/12 rounded bg-white focus:outline-none focus:border-[#C9A84C] transition-colors text-[#0D0D0D] placeholder-[#0D0D0D]/25"
              />
              <button
                onClick={addSkill}
                className="text-sm bg-[#0D0D0D] text-[#F7F4EE] px-4 py-2 rounded hover:bg-[#C9A84C] hover:text-[#0D0D0D] transition-colors font-medium"
              >
                Add
              </button>
            </div>
            <div className="flex flex-wrap gap-2">
              {resume.skills.map((s) => (
                <span
                  key={s}
                  className="inline-flex items-center gap-1.5 text-xs bg-[#0D0D0D]/5 border border-[#0D0D0D]/10 rounded-full px-3 py-1.5 font-medium"
                >
                  {s}
                  <button
                    onClick={() => removeSkill(s)}
                    className="text-[#0D0D0D]/30 hover:text-red-500 transition-colors text-xs leading-none"
                  >
                    ✕
                  </button>
                </span>
              ))}
            </div>
            {resume.skills.length === 0 && (
              <p className="text-sm text-[#0D0D0D]/30 text-center py-8">
                Add your key skills above
              </p>
            )}
          </div>
        )}

        {/* Projects */}
        {active === "projects" && (
          <div className="space-y-4 animate-fade-in">
            <div className="flex items-center justify-between">
              <SectionHeader title="Projects" />
              <button
                onClick={addProject}
                className="text-xs bg-[#0D0D0D] text-[#F7F4EE] px-3 py-1.5 rounded hover:bg-[#C9A84C] hover:text-[#0D0D0D] transition-colors font-medium"
              >
                + Add
              </button>
            </div>

            {resume.projects.length === 0 && (
              <EmptyState label="No projects added yet" action="+ Add project" onClick={addProject} />
            )}

            {resume.projects.map((p) => (
              <div key={p.id} className="border border-[#0D0D0D]/10 rounded-lg p-4 space-y-3 bg-[#F7F4EE]/50">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-[#0D0D0D]/40 uppercase tracking-wider">
                    {p.name || "New Project"}
                  </span>
                  <button onClick={() => removeProject(p.id)} className="text-[#0D0D0D]/20 hover:text-red-500 text-sm transition-colors">✕</button>
                </div>
                <Field label="Project Name" value={p.name} onChange={(v) => updateProject(p.id, "name", v)} placeholder="OpenMetrics" />
                <div>
                  <label className="text-xs font-medium text-[#0D0D0D]/60 uppercase tracking-wider block mb-1.5">Description</label>
                  <textarea
                    value={p.description}
                    onChange={(e) => updateProject(p.id, "description", e.target.value)}
                    rows={2}
                    placeholder="Open-source observability framework with 2.4K GitHub stars..."
                    className="w-full px-3 py-2 text-sm border border-[#0D0D0D]/12 rounded bg-white focus:outline-none focus:border-[#C9A84C] transition-colors text-[#0D0D0D] placeholder-[#0D0D0D]/25 leading-relaxed"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Technologies" value={p.tech} onChange={(v) => updateProject(p.id, "tech", v)} placeholder="TypeScript, React" />
                  <Field label="URL (optional)" value={p.url || ""} onChange={(v) => updateProject(p.id, "url", v)} placeholder="github.com/you/project" />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function SectionHeader({ title }: { title: string }) {
  return (
    <h2
      className="text-lg font-semibold text-[#0D0D0D]"
      style={{ fontFamily: "DM Serif Display, serif" }}
    >
      {title}
    </h2>
  );
}

interface FieldProps {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  type?: string;
  className?: string;
  disabled?: boolean;
}

function Field({ label, value, onChange, placeholder, type = "text", className = "", disabled }: FieldProps) {
  return (
    <div className={className}>
      <label className="text-xs font-medium text-[#0D0D0D]/60 uppercase tracking-wider block mb-1.5">
        {label}
      </label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        disabled={disabled}
        className="w-full px-3 py-2 text-sm border border-[#0D0D0D]/12 rounded bg-white focus:outline-none focus:border-[#C9A84C] transition-colors text-[#0D0D0D] placeholder-[#0D0D0D]/25 disabled:opacity-40 disabled:cursor-not-allowed"
      />
    </div>
  );
}

interface AIButtonProps {
  label: string;
  onClick: () => void;
  loading: boolean;
  icon: string;
  variant?: "primary" | "secondary";
}

function AIButton({ label, onClick, loading, icon, variant = "primary" }: AIButtonProps) {
  return (
    <button
      onClick={onClick}
      disabled={loading}
      className={`inline-flex items-center gap-1 text-xs px-2.5 py-1 rounded font-medium transition-all disabled:opacity-60 ${
        variant === "primary"
          ? "bg-[#C9A84C] text-[#0D0D0D] hover:bg-[#E8C96A]"
          : "bg-[#0D0D0D]/5 text-[#0D0D0D]/60 hover:bg-[#0D0D0D]/10"
      }`}
    >
      {loading ? <Spinner size="sm" /> : <span>{icon}</span>}
      {label}
    </button>
  );
}

function EmptyState({ label, action, onClick }: { label: string; action: string; onClick: () => void }) {
  return (
    <div className="text-center py-10 border border-dashed border-[#0D0D0D]/15 rounded-lg">
      <p className="text-sm text-[#0D0D0D]/30 mb-3">{label}</p>
      <button
        onClick={onClick}
        className="text-xs text-[#C9A84C] font-medium hover:underline"
      >
        {action}
      </button>
    </div>
  );
}
