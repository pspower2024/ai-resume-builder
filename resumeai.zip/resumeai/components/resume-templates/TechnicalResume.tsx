import { ResumeData } from "@/lib/types";

interface Props {
  resume: ResumeData;
}

function formatDate(d: string) {
  if (!d) return "";
  const [year, month] = d.split("-");
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  return month ? `${months[parseInt(month) - 1]} ${year}` : year;
}

export default function TechnicalResume({ resume }: Props) {
  const { personal, experience, education, skills, projects } = resume;

  return (
    <div
      className="bg-white text-[#0D0D0D] print:shadow-none"
      style={{
        fontFamily: "DM Sans, system-ui, sans-serif",
        fontSize: "8.5pt",
        lineHeight: "1.45",
        minHeight: "1056px",
      }}
    >
      {/* Left sidebar */}
      <div className="flex">
        <div className="w-[200px] flex-shrink-0 bg-[#F7F4EE] p-6 min-h-[1056px]">
          {/* Name */}
          <div className="mb-7 pb-5 border-b border-[#0D0D0D]/10">
            <h1
              className="text-[16pt] font-normal leading-tight mb-1"
              style={{ fontFamily: "DM Serif Display, Georgia, serif" }}
            >
              {personal.name || "Your Name"}
            </h1>
            <p className="text-[7.5pt] text-[#C9A84C] font-semibold tracking-wide">
              {personal.title}
            </p>
          </div>

          {/* Contact */}
          <div className="mb-6">
            <h2 className="text-[6.5pt] font-bold uppercase tracking-[0.15em] text-[#0D0D0D]/40 mb-2">
              Contact
            </h2>
            <div className="space-y-1.5 text-[7.5pt] text-[#0D0D0D]/60">
              {personal.email && <div className="break-all">{personal.email}</div>}
              {personal.phone && <div>{personal.phone}</div>}
              {personal.location && <div>{personal.location}</div>}
              {personal.linkedin && <div className="break-all">{personal.linkedin}</div>}
              {personal.website && <div className="break-all">{personal.website}</div>}
            </div>
          </div>

          {/* Skills */}
          {skills.length > 0 && (
            <div className="mb-6">
              <h2 className="text-[6.5pt] font-bold uppercase tracking-[0.15em] text-[#0D0D0D]/40 mb-2">
                Skills
              </h2>
              <div className="space-y-1">
                {skills.map((s) => (
                  <div key={s} className="flex items-center gap-2">
                    <div className="w-1 h-1 rounded-full bg-[#C9A84C] flex-shrink-0" />
                    <span className="text-[7.5pt] text-[#0D0D0D]/70">{s}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Education */}
          {education.length > 0 && (
            <div>
              <h2 className="text-[6.5pt] font-bold uppercase tracking-[0.15em] text-[#0D0D0D]/40 mb-2">
                Education
              </h2>
              <div className="space-y-3">
                {education.map((edu) => (
                  <div key={edu.id}>
                    <h3 className="font-semibold text-[8pt]">{edu.institution}</h3>
                    <p className="text-[7pt] text-[#0D0D0D]/55">
                      {edu.degree} {edu.field}
                    </p>
                    <p className="text-[7pt] text-[#0D0D0D]/35">
                      {formatDate(edu.endDate)}
                      {edu.gpa && ` · ${edu.gpa}`}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Main content */}
        <div className="flex-1 p-7 space-y-6">
          {/* Summary */}
          {personal.summary && (
            <section>
              <div className="flex items-center gap-3 mb-3">
                <div className="w-3 h-3 bg-[#C9A84C] rounded-sm flex-shrink-0" />
                <h2 className="text-[7pt] font-bold uppercase tracking-[0.15em] text-[#0D0D0D]/50">
                  Profile
                </h2>
              </div>
              <p className="text-[8.5pt] text-[#0D0D0D]/65 leading-relaxed pl-6">
                {personal.summary}
              </p>
            </section>
          )}

          {/* Experience */}
          {experience.length > 0 && (
            <section>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-3 h-3 bg-[#C9A84C] rounded-sm flex-shrink-0" />
                <h2 className="text-[7pt] font-bold uppercase tracking-[0.15em] text-[#0D0D0D]/50">
                  Experience
                </h2>
              </div>
              <div className="space-y-5 pl-6">
                {experience.map((exp) => (
                  <div key={exp.id}>
                    <div className="flex items-baseline justify-between mb-0.5">
                      <h3 className="font-semibold text-[9.5pt]">{exp.role}</h3>
                      <span className="text-[7pt] text-[#0D0D0D]/35 tabular-nums ml-2 flex-shrink-0">
                        {formatDate(exp.startDate)} – {exp.current ? "Present" : formatDate(exp.endDate)}
                      </span>
                    </div>
                    <p className="text-[7.5pt] text-[#C9A84C] font-semibold mb-2">{exp.company}</p>
                    <div className="text-[8pt] text-[#0D0D0D]/65 leading-relaxed space-y-0.5">
                      {exp.description.split("\n").map((line, i) => (
                        <p key={i}>{line}</p>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}

          {/* Projects */}
          {projects.length > 0 && (
            <section>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-3 h-3 bg-[#C9A84C] rounded-sm flex-shrink-0" />
                <h2 className="text-[7pt] font-bold uppercase tracking-[0.15em] text-[#0D0D0D]/50">
                  Projects
                </h2>
              </div>
              <div className="space-y-3 pl-6">
                {projects.map((p) => (
                  <div key={p.id}>
                    <div className="flex items-baseline justify-between">
                      <h3 className="font-semibold text-[9pt]">{p.name}</h3>
                      {p.url && (
                        <span className="text-[7pt] text-[#0D0D0D]/35 ml-2">{p.url}</span>
                      )}
                    </div>
                    <p className="text-[7.5pt] text-[#C9A84C] font-medium mb-0.5">{p.tech}</p>
                    <p className="text-[8pt] text-[#0D0D0D]/65 leading-relaxed">{p.description}</p>
                  </div>
                ))}
              </div>
            </section>
          )}
        </div>
      </div>
    </div>
  );
}
