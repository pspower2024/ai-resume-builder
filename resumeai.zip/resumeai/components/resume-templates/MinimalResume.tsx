import { ResumeData } from "@/lib/types";

interface Props {
  resume: ResumeData;
}

function formatDate(d: string) {
  if (!d) return "";
  const [year, month] = d.split("-");
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  return month ? `${months[parseInt(month) - 1]} ${year}` : year;
}

export default function MinimalResume({ resume }: Props) {
  const { personal, experience, education, skills, projects } = resume;

  return (
    <div
      className="bg-white text-[#0D0D0D] print:shadow-none"
      style={{
        fontFamily: "DM Sans, system-ui, sans-serif",
        fontSize: "9pt",
        lineHeight: "1.5",
        padding: "56px 60px",
        minHeight: "1056px",
      }}
    >
      {/* Header */}
      <div className="mb-8 pb-6 border-b border-[#0D0D0D]/15">
        <h1
          className="text-[24pt] font-normal mb-0.5"
          style={{ fontFamily: "DM Serif Display, Georgia, serif" }}
        >
          {personal.name || "Your Name"}
        </h1>
        <p className="text-[10pt] text-[#0D0D0D]/50 mb-4">{personal.title}</p>
        <div className="flex flex-wrap gap-x-5 gap-y-0.5 text-[7.5pt] text-[#0D0D0D]/45">
          {personal.email && <span>{personal.email}</span>}
          {personal.phone && <span>{personal.phone}</span>}
          {personal.location && <span>{personal.location}</span>}
          {personal.linkedin && <span>{personal.linkedin}</span>}
          {personal.website && <span>{personal.website}</span>}
        </div>
      </div>

      {/* Summary */}
      {personal.summary && (
        <div className="mb-7">
          <p className="text-[9pt] text-[#0D0D0D]/65 leading-relaxed max-w-2xl">
            {personal.summary}
          </p>
        </div>
      )}

      {/* Experience */}
      {experience.length > 0 && (
        <div className="mb-7">
          <h2 className="text-[7pt] uppercase tracking-[0.2em] text-[#0D0D0D]/30 mb-4 font-medium">
            Experience
          </h2>
          <div className="space-y-5">
            {experience.map((exp) => (
              <div key={exp.id} className="flex gap-8">
                <div className="w-28 flex-shrink-0 text-[7.5pt] text-[#0D0D0D]/35 pt-0.5">
                  <div>{formatDate(exp.startDate)}</div>
                  <div>–</div>
                  <div>{exp.current ? "Present" : formatDate(exp.endDate)}</div>
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-[9.5pt]">{exp.role}</h3>
                  <p className="text-[8pt] text-[#0D0D0D]/50 mb-1.5">{exp.company}</p>
                  <div className="text-[8.5pt] text-[#0D0D0D]/65 leading-relaxed space-y-0.5">
                    {exp.description.split("\n").map((line, i) => (
                      <p key={i}>{line}</p>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Education */}
      {education.length > 0 && (
        <div className="mb-7">
          <h2 className="text-[7pt] uppercase tracking-[0.2em] text-[#0D0D0D]/30 mb-4 font-medium">
            Education
          </h2>
          <div className="space-y-3">
            {education.map((edu) => (
              <div key={edu.id} className="flex gap-8">
                <div className="w-28 flex-shrink-0 text-[7.5pt] text-[#0D0D0D]/35 pt-0.5">
                  {formatDate(edu.endDate)}
                </div>
                <div>
                  <h3 className="font-semibold text-[9.5pt]">{edu.institution}</h3>
                  <p className="text-[8pt] text-[#0D0D0D]/50">
                    {edu.degree} · {edu.field}
                    {edu.gpa && ` · GPA ${edu.gpa}`}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 gap-8">
        {/* Skills */}
        {skills.length > 0 && (
          <div>
            <h2 className="text-[7pt] uppercase tracking-[0.2em] text-[#0D0D0D]/30 mb-3 font-medium">
              Skills
            </h2>
            <p className="text-[8.5pt] text-[#0D0D0D]/65 leading-relaxed">
              {skills.join(" · ")}
            </p>
          </div>
        )}

        {/* Projects */}
        {projects.length > 0 && (
          <div>
            <h2 className="text-[7pt] uppercase tracking-[0.2em] text-[#0D0D0D]/30 mb-3 font-medium">
              Projects
            </h2>
            <div className="space-y-2">
              {projects.map((p) => (
                <div key={p.id}>
                  <span className="font-semibold text-[8.5pt]">{p.name}</span>
                  {p.url && <span className="text-[7.5pt] text-[#0D0D0D]/35 ml-2">{p.url}</span>}
                  <p className="text-[8pt] text-[#0D0D0D]/55 leading-relaxed">{p.description}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
