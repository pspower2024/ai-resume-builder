import { ResumeData } from "@/lib/types";

interface Props {
  resume: ResumeData;
}

function formatDate(d: string) {
  if (!d) return "";
  const [year, month] = d.split("-");
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  return month ? `${months[parseInt(month) - 1]} ${year}` : year;
}

export default function ExecutiveResume({ resume }: Props) {
  const { personal, experience, education, skills, projects } = resume;

  return (
    <div
      className="bg-white text-[#0D0D0D] print:shadow-none"
      style={{
        fontFamily: "DM Sans, system-ui, sans-serif",
        fontSize: "9pt",
        lineHeight: "1.4",
        minHeight: "1056px",
      }}
    >
      {/* Header */}
      <div className="bg-[#0D0D0D] text-[#F7F4EE] px-10 py-8">
        <div className="flex items-start justify-between gap-6">
          <div>
            <h1
              className="text-[28pt] font-normal leading-tight mb-1"
              style={{ fontFamily: "DM Serif Display, Georgia, serif" }}
            >
              {personal.name || "Your Name"}
            </h1>
            <p className="text-[#C9A84C] text-[11pt] font-medium tracking-wide">
              {personal.title || "Your Professional Title"}
            </p>
          </div>
          {personal.summary && (
            <div className="max-w-xs text-[8pt] text-[#F7F4EE]/60 leading-relaxed text-right flex-shrink-0">
              {personal.summary}
            </div>
          )}
        </div>

        <div className="mt-5 pt-5 border-t border-white/10 flex flex-wrap gap-4 text-[7.5pt] text-[#F7F4EE]/50">
          {personal.email && <span>{personal.email}</span>}
          {personal.phone && <span>{personal.phone}</span>}
          {personal.location && <span>{personal.location}</span>}
          {personal.linkedin && <span>{personal.linkedin}</span>}
          {personal.website && <span>{personal.website}</span>}
        </div>
      </div>

      {/* Body */}
      <div className="px-10 py-7 grid grid-cols-3 gap-8">
        {/* Main column */}
        <div className="col-span-2 space-y-6">
          {/* Experience */}
          {experience.length > 0 && (
            <section>
              <h2 className="text-[7pt] font-semibold text-[#C9A84C] uppercase tracking-[0.15em] mb-3">
                Experience
              </h2>
              <div className="space-y-5">
                {experience.map((exp) => (
                  <div key={exp.id}>
                    <div className="flex items-baseline justify-between mb-0.5">
                      <h3 className="font-semibold text-[10pt]">{exp.role || "Role"}</h3>
                      <span className="text-[7.5pt] text-[#0D0D0D]/40 tabular-nums">
                        {formatDate(exp.startDate)} – {exp.current ? "Present" : formatDate(exp.endDate)}
                      </span>
                    </div>
                    <p className="text-[8pt] text-[#C9A84C] font-medium mb-2">{exp.company || "Company"}</p>
                    <div className="text-[8.5pt] text-[#0D0D0D]/70 leading-relaxed space-y-0.5">
                      {exp.description.split("\n").map((line, i) => (
                        <p key={i}>{line}</p>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}

          {/* Projects */}
          {projects.length > 0 && (
            <section>
              <h2 className="text-[7pt] font-semibold text-[#C9A84C] uppercase tracking-[0.15em] mb-3">
                Projects
              </h2>
              <div className="space-y-3">
                {projects.map((p) => (
                  <div key={p.id}>
                    <div className="flex items-baseline justify-between">
                      <h3 className="font-semibold text-[9.5pt]">{p.name}</h3>
                      {p.url && <span className="text-[7pt] text-[#0D0D0D]/40">{p.url}</span>}
                    </div>
                    <p className="text-[8pt] text-[#0D0D0D]/60 font-medium mb-0.5">{p.tech}</p>
                    <p className="text-[8.5pt] text-[#0D0D0D]/70 leading-relaxed">{p.description}</p>
                  </div>
                ))}
              </div>
            </section>
          )}
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Education */}
          {education.length > 0 && (
            <section>
              <h2 className="text-[7pt] font-semibold text-[#C9A84C] uppercase tracking-[0.15em] mb-3">
                Education
              </h2>
              <div className="space-y-3">
                {education.map((edu) => (
                  <div key={edu.id}>
                    <h3 className="font-semibold text-[9pt]">{edu.institution}</h3>
                    <p className="text-[8pt] text-[#0D0D0D]/60">
                      {edu.degree} {edu.field}
                    </p>
                    <p className="text-[7.5pt] text-[#0D0D0D]/40">
                      {formatDate(edu.startDate)} – {formatDate(edu.endDate)}
                      {edu.gpa && ` · GPA ${edu.gpa}`}
                    </p>
                  </div>
                ))}
              </div>
            </section>
          )}

          {/* Skills */}
          {skills.length > 0 && (
            <section>
              <h2 className="text-[7pt] font-semibold text-[#C9A84C] uppercase tracking-[0.15em] mb-3">
                Skills
              </h2>
              <div className="flex flex-wrap gap-1.5">
                {skills.map((s) => (
                  <span
                    key={s}
                    className="text-[7.5pt] bg-[#F7F4EE] px-2 py-0.5 rounded"
                  >
                    {s}
                  </span>
                ))}
              </div>
            </section>
          )}
        </div>
      </div>
    </div>
  );
}
